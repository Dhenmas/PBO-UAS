/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Windows 10 Pro
 */
public class thanos extends villain{
    
    //variabel
    String walk="berjalan";
    
    //fungsi
    void walk(){
        System.out.println("Thanos bergerak dengan cara = "+walk);
    }
}
