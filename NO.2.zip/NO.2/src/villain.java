/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Windows 10 Pro
 */
public class villain {
    
    //variabel
    String name="marvel heroes";
    String hitpoint="high";
    String attack="medium";
    
    //fungsi
    void name(){
        System.out.println("Villain merupakan karakter = "+name);
    }
    void hitpoint(){
        System.out.println("Villain hitpoint = "+hitpoint);
    }
    void attack(){
        System.out.println("Villain attack = "+attack);
    }
}
