# No.7-UAS-PBO
Repository ini berisikan source code jawaban nomor 7 pembuatan program dengan memanfaatkan constructor, abstract class dan interface.
